import { Redirect } from 'expo-router';

// This is a placeholder - the actual scan opens as a modal
export default function ScanTabScreen() {
  return <Redirect href="/scan" />;
}
